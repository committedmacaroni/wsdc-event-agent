"""WSDC Event Catalog: authoritative event catalog for the WCS Results Agent."""
__version__ = "0.1.0"
