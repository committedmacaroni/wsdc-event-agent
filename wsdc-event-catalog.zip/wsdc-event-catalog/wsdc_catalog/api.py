"""HTTP API (stdlib only). Thin layer over queries/sync/resolver so it can move to FastAPI later."""
from __future__ import annotations

import hmac
import json
import logging
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from .config import Config
from .db import connect, iso, utcnow
from .enrichment import ImportError_, import_external_event
from .fetcher import fetch_wsdc
from .queries import QueryError, get_event, get_series, list_events, list_sync_runs
from .resolver import resolve_event
from .sync import SyncAlreadyRunning, add_alias, run_wsdc_sync

log = logging.getLogger("wsdc_catalog.api")
MAX_BODY = 64 * 1024


class HttpError(Exception):
    def __init__(self, status: int, code: str, message: str, **extra):
        super().__init__(message)
        self.status, self.code, self.message, self.extra = status, code, message, extra


def make_handler(cfg: Config, fetcher=None):
    fetcher = fetcher or (lambda: fetch_wsdc(cfg.wsdc_url))

    class Handler(BaseHTTPRequestHandler):
        server_version = "WSDCEventCatalog/0.1"

        # ---------------------------------------------------------- plumbing
        def log_message(self, fmt, *args):
            log.info("%s %s", self.address_string(), fmt % args)

        def _send(self, status: int, payload):
            body = json.dumps(payload, default=str).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                raise HttpError(413, "body_too_large", "request body too large")
            if n == 0:
                return {}
            try:
                data = json.loads(self.rfile.read(n))
            except json.JSONDecodeError:
                raise HttpError(400, "invalid_json", "body must be JSON") from None
            if not isinstance(data, dict):
                raise HttpError(400, "invalid_json", "body must be a JSON object")
            return data

        def _auth(self, admin: bool):
            key = cfg.admin_api_key if admin else cfg.catalog_api_key
            if admin and not key:
                raise HttpError(403, "admin_disabled", "admin endpoints are disabled (ADMIN_API_KEY unset)")
            if not key:
                return  # read endpoints open only when CATALOG_API_KEY is unset (local dev)
            got = self.headers.get("Authorization", "")
            token = got[7:] if got.startswith("Bearer ") else ""
            ok = hmac.compare_digest(token, key) or (not admin and cfg.admin_api_key
                                                     and hmac.compare_digest(token, cfg.admin_api_key))
            if not ok:
                raise HttpError(401, "unauthorized", "missing or invalid bearer token")

        def _dispatch(self, method: str):
            url = urlparse(self.path)
            path = url.path.rstrip("/") or "/"
            params = {k: v[-1] for k, v in parse_qs(url.query).items()}
            conn = connect(cfg.db_path)
            try:
                for m, pattern, admin, fn in ROUTES:
                    if m != method:
                        continue
                    match = re.fullmatch(pattern, path)
                    if match:
                        if admin is not None:
                            self._auth(admin)
                        return self._send(*fn(self, conn, params, *match.groups()))
                raise HttpError(404, "not_found", f"no route for {method} {path}")
            except HttpError as e:
                self._send(e.status, {"error": {"code": e.code, "message": e.message, **e.extra}})
            except QueryError as e:
                self._send(400, {"error": {"code": "invalid_parameter", "message": str(e)}})
            except Exception:  # noqa: BLE001
                log.exception("unhandled error")
                self._send(500, {"error": {"code": "internal_error", "message": "internal error"}})
            finally:
                conn.close()

        def do_GET(self):
            self._dispatch("GET")

        def do_POST(self):
            self._dispatch("POST")

        # ---------------------------------------------------------- routes
        def health(self, conn, params):
            last = conn.execute("SELECT id, status, completed_at FROM sync_runs WHERE status='success' "
                                "ORDER BY id DESC LIMIT 1").fetchone()
            return 200, {"ok": True, "time": iso(utcnow()), "last_successful_sync": dict(last) if last else None}

        def events(self, conn, params):
            return 200, list_events(conn, params)

        def event(self, conn, params, event_id):
            ev = get_event(conn, event_id)
            if not ev:
                raise HttpError(404, "event_not_found", f"no event {event_id}")
            return 200, ev

        def series(self, conn, params, series_id):
            s = get_series(conn, series_id)
            if not s:
                raise HttpError(404, "series_not_found", f"no series {series_id}")
            return 200, s

        def resolve(self, conn, params):
            body = self._body()
            meta = {k: body.get(k) for k in ("name", "start_date", "end_date", "year", "city", "country")}
            return 200, resolve_event(conn, event_id=body.get("event_id"), metadata=meta)

        def sync(self, conn, params):
            body = self._body()
            try:
                run = run_wsdc_sync(conn, fetcher, force=bool(body.get("force")),
                                    snapshot_dir=cfg.snapshot_dir, source_url=cfg.wsdc_url)
            except SyncAlreadyRunning as e:
                raise HttpError(409, "sync_in_progress", str(e)) from None
            return (200 if run["status"] == "success" else 502), run

        def sync_runs(self, conn, params):
            try:
                limit = int(params.get("limit") or 20)
            except ValueError:
                raise QueryError("limit must be an integer") from None
            return 200, {"items": list_sync_runs(conn, limit)}

        def alias(self, conn, params, series_id):
            body = self._body()
            if not body.get("alias"):
                raise HttpError(400, "invalid_parameter", "alias is required")
            if not conn.execute("SELECT 1 FROM event_series WHERE id=?", (series_id,)).fetchone():
                raise HttpError(404, "series_not_found", f"no series {series_id}")
            created = add_alias(conn, series_id, body["alias"], body.get("source") or "manual", iso(utcnow()))
            return (201 if created else 200), {"created": created, "series": get_series(conn, series_id)}

        def import_event(self, conn, params):
            try:
                return 200, import_external_event(conn, self._body())
            except ImportError_ as e:
                raise HttpError(400, "invalid_parameter", str(e)) from None

    # (method, path regex, admin? None=public False=read-key True=admin-key, handler)
    ROUTES = [
        ("GET", r"/health", None, Handler.health),
        ("GET", r"/events", False, Handler.events),
        ("GET", r"/events/([A-Za-z0-9_]+)", False, Handler.event),
        ("GET", r"/series/([A-Za-z0-9_]+)", False, Handler.series),
        ("POST", r"/events/resolve", False, Handler.resolve),
        ("POST", r"/admin/sync-events", True, Handler.sync),
        ("GET", r"/admin/sync-runs", True, Handler.sync_runs),
        ("POST", r"/admin/series/([A-Za-z0-9_]+)/aliases", True, Handler.alias),
        ("POST", r"/admin/events/import", True, Handler.import_event),
    ]
    return Handler


def serve(cfg: Config, host: str = "0.0.0.0", port: int = 8080, fetcher=None) -> ThreadingHTTPServer:
    connect(cfg.db_path).close()  # create schema up front
    return ThreadingHTTPServer((host, port), make_handler(cfg, fetcher))
